import React, { useState, useMemo } from 'react';
import { TECH_ROLES, INITIAL_DEVON_SKILLS, ROLE_SKILL_COUNTS } from './data/rolesData.ts';
import { computeGapAnalysis } from './utils/gapRanking.ts';
import { Header } from './components/Header.tsx';
import { RoleSelector } from './components/RoleSelector.tsx';
import { TopGapCallout } from './components/TopGapCallout.tsx';
import { RankedGapsList } from './components/RankedGapsList.tsx';
import { DevonSkillsManager } from './components/DevonSkillsManager.tsx';
import { ConfidenceAdvice } from './components/ConfidenceAdvice.tsx';
import { JobPostingsExplorer } from './components/JobPostingsExplorer.tsx';
import { SlidersHorizontal, Info, Check, RefreshCw } from 'lucide-react';

export default function App() {
  // Devon's currently registered skills
  const [userSkills, setUserSkills] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('devon_skills');
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback to default
    }
    return INITIAL_DEVON_SKILLS;
  });

  // Selected role
  const [selectedRoleId, setSelectedRoleId] = useState<string>('jr-frontend-dev');

  // Custom simulation overrides (optional interactive testing for Devon to adjust total postings or skill counts)
  const [customTotalPostings, setCustomTotalPostings] = useState<number | null>(null);

  // Synchronize localStorage
  const updateSkills = (newSkills: string[]) => {
    setUserSkills(newSkills);
    try {
      localStorage.setItem('devon_skills', JSON.stringify(newSkills));
    } catch {
      // Ignore storage errors
    }
  };

  const handleAddSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (!trimmed) return;
    if (!userSkills.some((s) => s.toLowerCase() === trimmed.toLowerCase())) {
      updateSkills([...userSkills, trimmed]);
    }
  };

  const handleRemoveSkill = (skill: string) => {
    updateSkills(userSkills.filter((s) => s.toLowerCase() !== skill.toLowerCase()));
  };

  const handleResetProfile = () => {
    updateSkills(INITIAL_DEVON_SKILLS);
    setCustomTotalPostings(null);
  };

  // Find currently active role
  const selectedRole = useMemo(() => {
    return TECH_ROLES.find((r) => r.id === selectedRoleId) || TECH_ROLES[0];
  }, [selectedRoleId]);

  // Compute ranked gaps with pure deterministic ordering
  const analysis = useMemo(() => {
    return computeGapAnalysis(
      selectedRole,
      userSkills,
      undefined,
      customTotalPostings ?? undefined
    );
  }, [selectedRole, userSkills, customTotalPostings]);

  return (
    <div className="min-h-screen bg-[#F7F1DE] text-[#0D0D0D] flex flex-col font-sans">
      {/* Top Header */}
      <Header
        onResetSkills={handleResetProfile}
        acquiredSkillsCount={userSkills.length}
      />

      {/* Main Container with 8px-based spacing */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:p-8 flex flex-col gap-6">
        
        {/* Role Selection Section */}
        <RoleSelector
          roles={TECH_ROLES}
          selectedRoleId={selectedRoleId}
          onSelectRole={(id) => {
            setSelectedRoleId(id);
            setCustomTotalPostings(null); // reset simulation override when switching roles
          }}
        />

        {/* Selected Role Meta & Simulation Toolbar */}
        <div className="bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-col gap-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-bold text-[#0D0D0D] uppercase tracking-wide">
                Target Role:
              </span>
              <span className="text-lg font-bold text-[#0D0D0D]">
                {selectedRole.title}
              </span>
            </div>
            <p className="text-sm text-[#0D0D0D] max-w-2xl leading-relaxed">
              {selectedRole.description}
            </p>
          </div>

          {/* Interactive Posting Count Quick-Adjuster (helps test F2-5 small sample directly) */}
          <div className="flex items-center gap-2 bg-[#efe6cd] border border-[#0D0D0D] rounded-[4px] p-2 self-start sm:self-auto shrink-0">
            <span className="text-sm font-bold text-[#0D0D0D] flex items-center gap-1">
              <SlidersHorizontal className="w-4 h-4 text-[#0D0D0D]" />
              <span>Postings:</span>
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setCustomTotalPostings(6)}
                className={`min-h-[44px] px-3 py-1 text-sm font-bold rounded-[4px] border border-[#0D0D0D] transition-colors ${
                  analysis.totalPostings === 6
                    ? 'bg-[#A8842C] text-[#0D0D0D]'
                    : 'bg-[#F7F1DE] text-[#0D0D0D] hover:bg-[#e2d6b5]'
                }`}
                title="Test with small sample (6 postings < 10)"
              >
                6 (Small Sample)
              </button>
              <button
                type="button"
                onClick={() => setCustomTotalPostings(selectedRole.totalPostings)}
                className={`min-h-[44px] px-3 py-1 text-sm font-bold rounded-[4px] border border-[#0D0D0D] transition-colors ${
                  analysis.totalPostings === selectedRole.totalPostings
                    ? 'bg-[#A8842C] text-[#0D0D0D]'
                    : 'bg-[#F7F1DE] text-[#0D0D0D] hover:bg-[#e2d6b5]'
                }`}
                title="Use default market sample size"
              >
                Default ({selectedRole.totalPostings})
              </button>
            </div>
          </div>
        </div>

        {/* F2-3: Mark top-ranked missing skill as the first gap to close */}
        {analysis.firstGapToClose && (
          <TopGapCallout
            topGap={analysis.firstGapToClose}
            totalPostings={analysis.totalPostings}
            onMarkLearned={(skill) => handleAddSkill(skill)}
          />
        )}

        {/* F2-1, F2-2, F2-4, F2-5: Core Ranked Missing Skills List */}
        <RankedGapsList
          missingSkills={analysis.rankedMissingSkills}
          totalPostings={analysis.totalPostings}
          isSmallSample={analysis.isSmallSample}
          onAddSkill={(skill) => handleAddSkill(skill)}
        />

        {/* Gold section divider */}
        <div className="h-[2px] bg-[#A8842C] w-full" />

        {/* Confidence & Fit Advice for Devon */}
        <ConfidenceAdvice analysis={analysis} />

        {/* Gold section divider */}
        <div className="h-[2px] bg-[#A8842C] w-full" />

        {/* Devon's Skills Management */}
        <DevonSkillsManager
          userSkills={userSkills}
          roleAcquiredSkills={analysis.acquiredSkills}
          totalPostings={analysis.totalPostings}
          onAddSkill={handleAddSkill}
          onRemoveSkill={handleRemoveSkill}
        />

        {/* Actual Job Postings Inspector */}
        <JobPostingsExplorer
          roleTitle={selectedRole.title}
          totalPostings={analysis.totalPostings}
          postings={selectedRole.postings}
          userSkills={userSkills}
        />
      </main>

      {/* Footer */}
      <footer className="border-t-2 border-[#A8842C] bg-[#F7F1DE] py-6 px-4 md:px-8 mt-8">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-[#0D0D0D]">
          <div>
            <span className="font-bold text-[#0D0D0D]">Ranked Gaps Analyzer</span> &middot; Built for entry-level tech applicants.
          </div>
          <div className="text-sm text-[#0D0D0D]">
            All text &ge; 14px &middot; Arial typography &middot; 8px spatial grid
          </div>
        </div>
      </footer>
    </div>
  );
}
