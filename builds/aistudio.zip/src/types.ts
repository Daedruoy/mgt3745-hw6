export interface JobPosting {
  id: string;
  title: string;
  company: string;
  location: string;
  requiredSkills: string[];
  preferredSkills?: string[];
  snippet: string;
}

export interface TechRole {
  id: string;
  title: string;
  category: string;
  totalPostings: number;
  postings: JobPosting[];
  description: string;
}

export interface SkillDemand {
  name: string;
  postingCount: number;
  totalPostings: number;
  percentage: number;
  isFirstGap: boolean;
  status: 'missing' | 'acquired';
  postingsWithSkill: string[]; // IDs or titles of postings
}

export interface GapAnalysisResult {
  roleId: string;
  roleTitle: string;
  totalPostings: number;
  isSmallSample: boolean;
  rankedMissingSkills: SkillDemand[];
  acquiredSkills: SkillDemand[];
  firstGapToClose: SkillDemand | null;
  overallMatchRate: number; // % of total postings where user has at least 50% of required skills
  directSkillMatchRate: number; // user acquired skills count vs unique skills in role
}
