import { TechRole, SkillDemand, GapAnalysisResult } from '../types.ts';
import { ROLE_SKILL_COUNTS } from '../data/rolesData.ts';

/**
 * Normalizes skill string for consistent matching
 */
export function normalizeSkill(skill: string): string {
  return skill.trim().toLowerCase();
}

/**
 * Checks if a user has acquired a skill (case-insensitive)
 */
export function userHasSkill(userSkills: string[], skillName: string): boolean {
  const normalizedTarget = normalizeSkill(skillName);
  return userSkills.some((s) => normalizeSkill(s) === normalizedTarget);
}

/**
 * Computes the ranked gap analysis adhering to:
 * F2-1: Order missing skills by posting count, highest first.
 * F2-2: Show posting count beside each skill and total postings for the role.
 * F2-3: Mark top-ranked missing skill as the first gap to close.
 * F2-4: If two skills have the same count, order them alphabetically.
 * F2-5: If role has fewer than 10 postings, say the sample is small next to ranking.
 */
export function computeGapAnalysis(
  role: TechRole,
  userSkills: string[],
  customSkillCounts?: Record<string, number>,
  customTotalPostings?: number
): GapAnalysisResult {
  const totalPostings = customTotalPostings ?? role.totalPostings;
  const isSmallSample = totalPostings < 10;

  // Retrieve skill counts for this role
  const rawCounts = customSkillCounts ?? ROLE_SKILL_COUNTS[role.id] ?? {};

  // Build skill demand array
  const allDemands: SkillDemand[] = Object.entries(rawCounts).map(([name, count]) => {
    const isAcquired = userHasSkill(userSkills, name);
    const percentage = totalPostings > 0 ? Math.round((count / totalPostings) * 100) : 0;
    
    // Find matching postings if available in role data
    const matchedPostings = role.postings
      .filter((p) => p.requiredSkills.some((req) => normalizeSkill(req) === normalizeSkill(name)))
      .map((p) => `${p.company} (${p.title})`);

    return {
      name,
      postingCount: count,
      totalPostings,
      percentage,
      isFirstGap: false,
      status: isAcquired ? 'acquired' : 'missing',
      postingsWithSkill: matchedPostings,
    };
  });

  // Split into missing vs acquired
  const missing = allDemands.filter((d) => d.status === 'missing');
  const acquired = allDemands.filter((d) => d.status === 'acquired');

  // F2-1 and F2-4: Sort missing skills:
  // 1. By posting count, highest first
  // 2. Tie-break: alphabetically (localeCompare) for deterministic order
  missing.sort((a, b) => {
    if (b.postingCount !== a.postingCount) {
      return b.postingCount - a.postingCount; // F2-1: highest first
    }
    return a.name.localeCompare(b.name, 'en', { sensitivity: 'base' }); // F2-4: alphabetical tie break
  });

  // Sort acquired skills similarly for clean presentation
  acquired.sort((a, b) => {
    if (b.postingCount !== a.postingCount) {
      return b.postingCount - a.postingCount;
    }
    return a.name.localeCompare(b.name, 'en', { sensitivity: 'base' });
  });

  // F2-3: Mark the top-ranked missing skill as the first gap to close
  if (missing.length > 0) {
    missing[0].isFirstGap = true;
  }

  const firstGapToClose = missing.length > 0 ? missing[0] : null;

  // Calculate market match rate and direct coverage
  const totalSkillDemandsCount = allDemands.length;
  const directSkillMatchRate = totalSkillDemandsCount > 0 
    ? Math.round((acquired.length / totalSkillDemandsCount) * 100)
    : 0;

  // Calculate weighted posting demand coverage
  const totalPostingMentions = allDemands.reduce((sum, d) => sum + d.postingCount, 0);
  const acquiredPostingMentions = acquired.reduce((sum, d) => sum + d.postingCount, 0);
  const overallMatchRate = totalPostingMentions > 0 
    ? Math.round((acquiredPostingMentions / totalPostingMentions) * 100)
    : 0;

  return {
    roleId: role.id,
    roleTitle: role.title,
    totalPostings,
    isSmallSample,
    rankedMissingSkills: missing,
    acquiredSkills: acquired,
    firstGapToClose,
    overallMatchRate,
    directSkillMatchRate,
  };
}
