import React from 'react';
import { SkillDemand } from '../types.ts';
import { Star, ArrowRight, CheckCircle2 } from 'lucide-react';

interface TopGapCalloutProps {
  topGap: SkillDemand;
  totalPostings: number;
  onMarkLearned: (skillName: string) => void;
}

export const TopGapCallout: React.FC<TopGapCalloutProps> = ({
  topGap,
  totalPostings,
  onMarkLearned,
}) => {
  return (
    <section 
      aria-label="First gap to close recommendation"
      className="border-2 border-[#0D0D0D] bg-[#F7F1DE] rounded-[4px] p-6 shadow-sm flex flex-col gap-4 relative overflow-hidden"
    >
      {/* Decorative top accent line in gold */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-[#A8842C]" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-[4px] bg-[#A8842C] flex items-center justify-center text-[#0D0D0D] shrink-0">
            <Star className="w-5 h-5 fill-current text-[#0D0D0D]" />
          </div>
          <div>
            {/* Heading in gold */}
            <h3 className="text-xl font-bold text-[#A8842C] tracking-tight">
              First Gap to Close: {topGap.name}
            </h3>
            <p className="text-sm font-bold text-[#0D0D0D] uppercase tracking-wide">
              Top-Ranked Missing Skill Priority
            </p>
          </div>
        </div>

        {/* F2-2: Posting count beside skill and total postings */}
        <div className="bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-3 flex flex-col sm:items-end">
          <span className="text-sm font-bold text-[#0D0D0D]">
            Market Requirement
          </span>
          <span className="text-base font-bold text-[#0D0D0D]">
            {topGap.postingCount} of {totalPostings} postings ({topGap.percentage}%)
          </span>
        </div>
      </div>

      {/* Gold section divider */}
      <div className="h-[2px] bg-[#A8842C] w-full" />

      {/* Actionable advice for Devon */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
        <div className="md:col-span-2 text-sm text-[#0D0D0D] leading-relaxed flex flex-col gap-2">
          <p>
            <strong>Why this skill first:</strong> More employers hiring for this role ask for <strong>{topGap.name}</strong> than any other skill you do not currently possess ({topGap.postingCount} out of {totalPostings} active listings).
          </p>
          <p>
            Closing this single gap unlocks qualification for up to <strong>{topGap.percentage}%</strong> of all analyzed job listings. You do not need to learn everything before applying—starting here yields the highest return on your study hours.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={() => onMarkLearned(topGap.name)}
            className="min-h-[48px] px-6 py-3 bg-[#A8842C] text-[#0D0D0D] font-bold text-base rounded-[4px] border-2 border-[#0D0D0D] hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#0D0D0D]"
          >
            <CheckCircle2 className="w-5 h-5 text-[#0D0D0D]" />
            <span>Mark {topGap.name} as Learned</span>
          </button>
          <span className="text-sm text-center text-[#0D0D0D]">
            Instantly re-ranks the next highest market gap.
          </span>
        </div>
      </div>
    </section>
  );
};
