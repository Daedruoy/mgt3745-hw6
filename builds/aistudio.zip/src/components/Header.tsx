import React from 'react';
import { Target, User, Sparkles, RefreshCw } from 'lucide-react';

interface HeaderProps {
  onResetSkills: () => void;
  acquiredSkillsCount: number;
}

export const Header: React.FC<HeaderProps> = ({ onResetSkills, acquiredSkillsCount }) => {
  return (
    <header className="border-b-2 border-[#A8842C] bg-[#F7F1DE] py-6 px-4 md:px-8">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-[4px] bg-[#0D0D0D] flex items-center justify-center text-[#F7F1DE] shrink-0">
              <Target className="w-6 h-6 text-[#A8842C]" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-[#A8842C] tracking-tight leading-tight">
                Ranked Gaps
              </h1>
              <p className="text-sm font-bold text-[#0D0D0D] tracking-wide uppercase">
                Tech Role Fit & Skill Priority Analyzer
              </p>
            </div>
          </div>
          <p className="text-sm text-[#0D0D0D] max-w-2xl leading-relaxed mt-1">
            Built for entry-level tech applicants. Determine whether you should apply even if you do not meet every listed requirement, and focus your energy on the missing skills that matter most.
          </p>
        </div>

        {/* Devon's Profile Status Banner */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-[4px] bg-[#0D0D0D] flex items-center justify-center text-[#F7F1DE] shrink-0">
              <User className="w-5 h-5 text-[#A8842C]" />
            </div>
            <div>
              <div className="text-sm font-bold text-[#0D0D0D]">
                Devon &middot; Entry-Level Applicant
              </div>
              <div className="text-sm text-[#0D0D0D]">
                {acquiredSkillsCount} skills in profile
              </div>
            </div>
          </div>

          <button
            onClick={onResetSkills}
            type="button"
            className="min-h-[44px] px-4 py-2 bg-[#A8842C] text-[#0D0D0D] font-bold text-sm rounded-[4px] hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2 border border-[#0D0D0D]"
            title="Reset Devon's skills to default"
          >
            <RefreshCw className="w-4 h-4 text-[#0D0D0D]" />
            <span>Reset Profile</span>
          </button>
        </div>
      </div>
    </header>
  );
};
