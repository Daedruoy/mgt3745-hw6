import React from 'react';
import { TechRole } from '../types.ts';
import { Briefcase, AlertTriangle, Scale } from 'lucide-react';

interface RoleSelectorProps {
  roles: TechRole[];
  selectedRoleId: string;
  onSelectRole: (roleId: string) => void;
}

export const RoleSelector: React.FC<RoleSelectorProps> = ({
  roles,
  selectedRoleId,
  onSelectRole,
}) => {
  return (
    <div className="bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-4 md:p-6 flex flex-col gap-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#0D0D0D] pb-3">
        <div>
          <h2 className="text-xl font-bold text-[#A8842C] tracking-tight">
            Select Target Tech Role
          </h2>
          <p className="text-sm text-[#0D0D0D] mt-1">
            Analyze market requirements across active job postings for entry-level positions.
          </p>
        </div>
        <div className="text-sm font-bold text-[#0D0D0D]">
          {roles.length} Roles Catalogued
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {roles.map((role) => {
          const isSelected = role.id === selectedRoleId;
          const isSmall = role.totalPostings < 10;
          const isTiedDemo = role.id === 'tied-test-role';

          return (
            <button
              key={role.id}
              type="button"
              onClick={() => onSelectRole(role.id)}
              className={`min-h-[56px] text-left p-4 rounded-[4px] transition-all flex flex-col justify-between gap-2 border ${
                isSelected
                  ? 'border-2 border-[#0D0D0D] bg-[#A8842C] text-[#0D0D0D] shadow-sm'
                  : 'border-[#0D0D0D] bg-[#F7F1DE] text-[#0D0D0D] hover:bg-[#efe6cd]'
              } focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#0D0D0D]`}
            >
              <div className="flex items-start justify-between gap-2">
                <span className="font-bold text-base leading-snug">
                  {role.title}
                </span>
                {isSmall && (
                  <span
                    className={`text-sm font-bold shrink-0 flex items-center gap-1 ${
                      isSelected ? 'text-[#0D0D0D]' : 'text-[#0D0D0D]'
                    }`}
                    title="Sample is under 10 postings"
                  >
                    <AlertTriangle className="w-4 h-4 shrink-0 text-[#0D0D0D]" />
                    <span>&lt;10 Postings</span>
                  </span>
                )}
                {isTiedDemo && (
                  <span
                    className={`text-sm font-bold shrink-0 flex items-center gap-1 ${
                      isSelected ? 'text-[#0D0D0D]' : 'text-[#0D0D0D]'
                    }`}
                    title="Tied skill counts to test alphabetical sorting"
                  >
                    <Scale className="w-4 h-4 shrink-0 text-[#0D0D0D]" />
                    <span>Tie Test</span>
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between text-sm pt-2 border-t border-[#0D0D0D]/20">
                <span className="text-sm">{role.category}</span>
                <span className="font-bold text-sm">
                  {role.totalPostings} {role.totalPostings === 1 ? 'posting' : 'postings'}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
