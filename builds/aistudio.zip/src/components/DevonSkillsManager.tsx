import React, { useState } from 'react';
import { SkillDemand } from '../types.ts';
import { Plus, X, Check, Award } from 'lucide-react';

interface DevonSkillsManagerProps {
  userSkills: string[];
  roleAcquiredSkills: SkillDemand[];
  totalPostings: number;
  onAddSkill: (skill: string) => void;
  onRemoveSkill: (skill: string) => void;
}

export const DevonSkillsManager: React.FC<DevonSkillsManagerProps> = ({
  userSkills,
  roleAcquiredSkills,
  totalPostings,
  onAddSkill,
  onRemoveSkill,
}) => {
  const [newSkillInput, setNewSkillInput] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkillInput.trim()) return;
    onAddSkill(newSkillInput.trim());
    setNewSkillInput('');
  };

  return (
    <section 
      aria-label="Devon's Skills Portfolio"
      className="bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-4 md:p-6 flex flex-col gap-4 shadow-sm"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#0D0D0D] pb-3">
        <div>
          {/* Section heading in Gold */}
          <h3 className="text-xl font-bold text-[#A8842C] tracking-tight">
            Devon's Acquired Skills
          </h3>
          <p className="text-sm text-[#0D0D0D] mt-1">
            Toggle or add your coursework, personal project tools, and verified competencies.
          </p>
        </div>
        <div className="text-sm font-bold text-[#0D0D0D]">
          {userSkills.length} Total Registered
        </div>
      </div>

      {/* Add Skill Form */}
      <form onSubmit={handleAdd} className="flex flex-col sm:flex-row gap-2">
        <label htmlFor="skill-input" className="sr-only">Add a new skill</label>
        <input
          id="skill-input"
          type="text"
          value={newSkillInput}
          onChange={(e) => setNewSkillInput(e.target.value)}
          placeholder="e.g. TypeScript, Docker, SQL..."
          className="min-h-[44px] flex-1 px-4 py-2 border-2 border-[#0D0D0D] rounded-[4px] bg-[#F7F1DE] text-[#0D0D0D] text-base placeholder-[#0D0D0D]/60 focus:outline-none focus:ring-2 focus:ring-[#A8842C]"
        />
        <button
          type="submit"
          className="min-h-[44px] px-6 py-2 bg-[#A8842C] text-[#0D0D0D] font-bold text-base rounded-[4px] border-2 border-[#0D0D0D] hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5 text-[#0D0D0D]" />
          <span>Add Skill</span>
        </button>
      </form>

      {/* Role matched skills breakdown */}
      <div className="flex flex-col gap-2 pt-2">
        <h4 className="text-base font-bold text-[#0D0D0D] flex items-center gap-2">
          <Award className="w-5 h-5 text-[#A8842C]" />
          <span>Skills Matching This Role ({roleAcquiredSkills.length})</span>
        </h4>

        {roleAcquiredSkills.length === 0 ? (
          <p className="text-sm text-[#0D0D0D]">
            None of your currently registered skills are listed among the top requirements for this role yet.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {roleAcquiredSkills.map((skill) => (
              <div
                key={skill.name}
                className="border border-[#0D0D0D] bg-[#efe6cd] rounded-[4px] p-3 flex items-center justify-between gap-2"
              >
                <div className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-[#0D0D0D] shrink-0" />
                  <div>
                    <span className="font-bold text-base text-[#0D0D0D]">
                      {skill.name}
                    </span>
                    <span className="block text-sm text-[#0D0D0D]">
                      {skill.postingCount} of {totalPostings} postings ({skill.percentage}%)
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onRemoveSkill(skill.name)}
                  className="min-h-[44px] min-w-[44px] p-2 hover:bg-[#e2d6b5] text-[#0D0D0D] rounded-[4px] flex items-center justify-center transition-colors"
                  title={`Remove ${skill.name} from skills`}
                >
                  <X className="w-5 h-5 text-[#0D0D0D]" />
                  <span className="sr-only">Remove {skill.name}</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* All other acquired skills */}
      {userSkills.length > 0 && (
        <div className="flex flex-col gap-2 pt-2 border-t border-[#0D0D0D]">
          <h4 className="text-base font-bold text-[#0D0D0D]">
            All Registered Profile Skills:
          </h4>
          <div className="flex flex-wrap gap-2">
            {userSkills.map((skill) => {
              const matchesCurrentRole = roleAcquiredSkills.some(
                (r) => r.name.toLowerCase() === skill.toLowerCase()
              );

              return (
                <div
                  key={skill}
                  className="min-h-[44px] border border-[#0D0D0D] bg-[#F7F1DE] rounded-[4px] px-3 py-2 flex items-center gap-2"
                >
                  <span className="text-sm font-bold text-[#0D0D0D]">
                    {skill}
                  </span>
                  {matchesCurrentRole && (
                    <span className="text-sm text-[#0D0D0D] font-bold">
                      &middot; Active Match
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => onRemoveSkill(skill)}
                    className="min-h-[36px] min-w-[36px] p-1 hover:bg-[#efe6cd] text-[#0D0D0D] rounded-[4px] flex items-center justify-center"
                    title={`Remove ${skill}`}
                  >
                    <X className="w-4 h-4 text-[#0D0D0D]" />
                    <span className="sr-only">Remove {skill}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
};
