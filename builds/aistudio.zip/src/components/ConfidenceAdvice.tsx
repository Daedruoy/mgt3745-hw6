import React from 'react';
import { GapAnalysisResult } from '../types.ts';
import { ShieldCheck, HelpCircle, TrendingUp, CheckSquare } from 'lucide-react';

interface ConfidenceAdviceProps {
  analysis: GapAnalysisResult;
}

export const ConfidenceAdvice: React.FC<ConfidenceAdviceProps> = ({ analysis }) => {
  const { overallMatchRate, directSkillMatchRate, firstGapToClose, totalPostings } = analysis;

  // Practical benchmark for entry level: >= 50% match rate is strong candidate territory
  const isHighFit = overallMatchRate >= 65;
  const isModerateFit = overallMatchRate >= 40 && overallMatchRate < 65;

  // Potential bump if top gap closed
  const potentialBoost = firstGapToClose 
    ? Math.min(100, overallMatchRate + Math.round((firstGapToClose.postingCount / Math.max(totalPostings, 1)) * 30))
    : overallMatchRate;

  return (
    <section 
      aria-label="Application Confidence Assessment"
      className="bg-[#F7F1DE] border-2 border-[#0D0D0D] rounded-[4px] p-4 md:p-6 flex flex-col gap-4 shadow-sm"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#0D0D0D] pb-3">
        <div>
          {/* Section heading in Gold */}
          <h3 className="text-xl font-bold text-[#A8842C] tracking-tight">
            Should Devon Apply? Confidence Assessment
          </h3>
          <p className="text-sm text-[#0D0D0D] mt-1">
            Data-backed guidance based on tech hiring patterns rather than job description wish-lists.
          </p>
        </div>
        <div className="bg-[#efe6cd] border border-[#0D0D0D] px-3 py-1.5 rounded-[4px] text-sm font-bold text-[#0D0D0D]">
          Fit Score: {overallMatchRate}%
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Core Verdict Card */}
        <div className="border border-[#0D0D0D] bg-[#efe6cd] rounded-[4px] p-4 flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-[#A8842C] shrink-0" />
            <h4 className="text-lg font-bold text-[#0D0D0D]">
              {isHighFit 
                ? 'Strong Match — Apply Immediately' 
                : isModerateFit 
                  ? 'Viable Candidate — Apply with Targeted Narrative'
                  : 'Stretch Opportunity — Build Top Gap First or Apply Strategically'}
            </h4>
          </div>

          <p className="text-sm text-[#0D0D0D] leading-relaxed">
            {isHighFit && (
              <>
                You match <strong>{overallMatchRate}%</strong> of employer demand for this role across {totalPostings} analyzed postings. Engineering managers almost never find candidates matching 100% of junior bullet points. Your existing skills cover the fundamental baseline.
              </>
            )}
            {isModerateFit && (
              <>
                You match <strong>{overallMatchRate}%</strong> of aggregate market demand. In entry-level hiring, candidates who demonstrate strong fundamentals in 50% of the stack and show curiosity for the remaining stack are regularly hired.
              </>
            )}
            {!isHighFit && !isModerateFit && (
              <>
                You currently match <strong>{overallMatchRate}%</strong> of market demand. You can still apply if you have relevant projects, but focusing on closing the #1 ranked missing skill will dramatically increase your callback probability.
              </>
            )}
          </p>

          <div className="border-t border-[#0D0D0D]/20 pt-2 text-sm text-[#0D0D0D]">
            <strong>Reality check:</strong> The "ideal candidate" described in job listings is a wish-list, not a rigid checklist. Missing one or two secondary tools should never prevent you from submitting.
          </div>
        </div>

        {/* Priority Leverage Simulator */}
        <div className="border border-[#0D0D0D] bg-[#F7F1DE] rounded-[4px] p-4 flex flex-col justify-between gap-3">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#A8842C] shrink-0" />
              <h4 className="text-base font-bold text-[#0D0D0D]">
                One-Gap Leverage Projection
              </h4>
            </div>

            {firstGapToClose ? (
              <p className="text-sm text-[#0D0D0D] leading-relaxed">
                By focusing your study time specifically on <strong>{firstGapToClose.name}</strong> ({firstGapToClose.postingCount} of {totalPostings} postings), you increase your market alignment from <strong>{overallMatchRate}%</strong> up to approximately <strong>{potentialBoost}%</strong>.
              </p>
            ) : (
              <p className="text-sm text-[#0D0D0D]">
                You have closed all identified skill gaps for this role!
              </p>
            )}
          </div>

          <div className="bg-[#efe6cd] border border-[#0D0D0D] rounded-[4px] p-3 flex flex-col gap-1">
            <span className="text-sm font-bold text-[#0D0D0D]">
              Devon's Application Rule of Thumb:
            </span>
            <span className="text-sm text-[#0D0D0D]">
              &bull; If you have &gt;45% match: Submit application now.
            </span>
            <span className="text-sm text-[#0D0D0D]">
              &bull; In your cover note or interview: Highlight matched skills, and mention you are already building projects with the top gap skill.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
