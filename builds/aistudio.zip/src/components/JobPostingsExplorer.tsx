import React, { useState } from 'react';
import { JobPosting } from '../types.ts';
import { userHasSkill } from '../utils/gapRanking.ts';
import { Building2, MapPin, Check, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface JobPostingsExplorerProps {
  roleTitle: string;
  totalPostings: number;
  postings: JobPosting[];
  userSkills: string[];
}

export const JobPostingsExplorer: React.FC<JobPostingsExplorerProps> = ({
  roleTitle,
  totalPostings,
  postings,
  userSkills,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <section 
      aria-label="Job Postings Sample Explorer"
      className="bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-4 md:p-6 flex flex-col gap-4 shadow-sm"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#0D0D0D] pb-3">
        <div>
          {/* Section heading in Gold */}
          <h3 className="text-xl font-bold text-[#A8842C] tracking-tight">
            Active Job Postings Sample ({postings.length} of {totalPostings} Sampled)
          </h3>
          <p className="text-sm text-[#0D0D0D] mt-1">
            Examine real requirements from tech employers for {roleTitle}.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="min-h-[44px] px-4 py-2 bg-[#A8842C] text-[#0D0D0D] font-bold text-sm rounded-[4px] border border-[#0D0D0D] hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-2 self-start sm:self-auto"
        >
          <span>{isExpanded ? 'Hide Postings List' : 'View Sample Postings'}</span>
          {isExpanded ? <ChevronUp className="w-4 h-4 text-[#0D0D0D]" /> : <ChevronDown className="w-4 h-4 text-[#0D0D0D]" />}
        </button>
      </div>

      {isExpanded ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {postings.map((posting) => {
            const matchedSkills = posting.requiredSkills.filter((s) =>
              userHasSkill(userSkills, s)
            );
            const missingSkillsInJob = posting.requiredSkills.filter(
              (s) => !userHasSkill(userSkills, s)
            );
            const matchPercentage = Math.round(
              (matchedSkills.length / Math.max(posting.requiredSkills.length, 1)) * 100
            );

            return (
              <div
                key={posting.id}
                className="border border-[#0D0D0D] bg-[#efe6cd] rounded-[4px] p-4 flex flex-col justify-between gap-3"
              >
                <div className="flex flex-col gap-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-base text-[#0D0D0D] leading-snug">
                        {posting.title}
                      </h4>
                      <div className="flex items-center gap-2 text-sm text-[#0D0D0D] mt-1">
                        <Building2 className="w-4 h-4 shrink-0 text-[#0D0D0D]" />
                        <span>{posting.company}</span>
                        <span>&middot;</span>
                        <MapPin className="w-4 h-4 shrink-0 text-[#0D0D0D]" />
                        <span>{posting.location}</span>
                      </div>
                    </div>

                    <div className="border border-[#0D0D0D] bg-[#F7F1DE] px-2 py-1 rounded-[4px] text-sm font-bold text-[#0D0D0D] shrink-0">
                      {matchPercentage}% Fit
                    </div>
                  </div>

                  <p className="text-sm text-[#0D0D0D] italic border-l-2 border-[#A8842C] pl-2 my-1">
                    "{posting.snippet}"
                  </p>
                </div>

                <div className="flex flex-col gap-2 pt-2 border-t border-[#0D0D0D]/20">
                  <div className="text-sm">
                    <span className="font-bold text-[#0D0D0D]">Matched: </span>
                    <span className="text-[#0D0D0D]">
                      {matchedSkills.length > 0 ? matchedSkills.join(', ') : 'None yet'}
                    </span>
                  </div>
                  <div className="text-sm">
                    <span className="font-bold text-[#0D0D0D]">Gaps to address: </span>
                    <span className="text-[#0D0D0D]">
                      {missingSkillsInJob.length > 0 ? missingSkillsInJob.join(', ') : 'None — 100% matched!'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-sm text-[#0D0D0D]">
          Click "View Sample Postings" to inspect individual company listings, requirements, and your calculated fit per posting.
        </div>
      )}
    </section>
  );
};
