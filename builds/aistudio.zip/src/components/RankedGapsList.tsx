import React from 'react';
import { SkillDemand } from '../types.ts';
import { Check, Plus, AlertTriangle, ArrowUpRight, Scale } from 'lucide-react';

interface RankedGapsListProps {
  missingSkills: SkillDemand[];
  totalPostings: number;
  isSmallSample: boolean;
  onAddSkill: (skillName: string) => void;
}

export const RankedGapsList: React.FC<RankedGapsListProps> = ({
  missingSkills,
  totalPostings,
  isSmallSample,
  onAddSkill,
}) => {
  return (
    <section 
      aria-label="Ranked Missing Skills List"
      className="bg-[#F7F1DE] border border-[#0D0D0D] rounded-[4px] p-4 md:p-6 flex flex-col gap-4 shadow-sm"
    >
      {/* Ranking Header with Small Sample notice (F2-5) */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#0D0D0D] pb-4">
        <div className="flex flex-wrap items-center gap-2">
          {/* Section heading in Gold */}
          <h3 className="text-xl font-bold text-[#A8842C] tracking-tight">
            Ranked Missing Skills
          </h3>

          {/* F2-5: IF the role has fewer than 10 postings, THEN the system SHALL say the sample is small next to the ranking */}
          {isSmallSample && (
            <div 
              role="status"
              className="border border-[#0D0D0D] bg-[#efe6cd] text-[#0D0D0D] font-bold text-sm px-3 py-1 rounded-[4px] flex items-center gap-1.5 shadow-xs"
            >
              <AlertTriangle className="w-4 h-4 text-[#0D0D0D] shrink-0" />
              <span>The sample is small ({totalPostings} postings)</span>
            </div>
          )}
        </div>

        {/* F2-2: Total postings for the role */}
        <div className="text-sm font-bold text-[#0D0D0D] bg-[#efe6cd] px-3 py-1.5 rounded-[4px] border border-[#0D0D0D] self-start md:self-auto">
          Total Postings for Role: {totalPostings}
        </div>
      </div>

      {/* Explanation for Devon */}
      <div className="text-sm text-[#0D0D0D] leading-relaxed">
        Ordered by the number of active job listings requesting each skill (highest employer demand first). If two skills share the exact same posting count, they are sorted alphabetically to prevent unexpected layout shifts.
      </div>

      {/* Missing Skills List */}
      {missingSkills.length === 0 ? (
        <div className="border-2 border-dashed border-[#0D0D0D] rounded-[4px] p-8 text-center bg-[#efe6cd]/50 flex flex-col items-center gap-2">
          <div className="w-12 h-12 rounded-[4px] bg-[#A8842C] text-[#0D0D0D] font-bold text-xl flex items-center justify-center">
            ✓
          </div>
          <h4 className="text-lg font-bold text-[#A8842C]">
            No Skill Gaps Detected
          </h4>
          <p className="text-sm text-[#0D0D0D] max-w-md">
            You meet 100% of the commonly requested skills for this role in our database. You are in an exceptional position to apply right now!
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {missingSkills.map((skill, index) => {
            const isTopRanked = skill.isFirstGap || index === 0; // F2-3
            const nextSkill = missingSkills[index + 1];
            const prevSkill = missingSkills[index - 1];
            const isTied = (nextSkill && nextSkill.postingCount === skill.postingCount) ||
                           (prevSkill && prevSkill.postingCount === skill.postingCount);

            return (
              <div
                key={skill.name}
                className={`border rounded-[4px] p-4 transition-all flex flex-col gap-3 ${
                  isTopRanked
                    ? 'border-2 border-[#0D0D0D] bg-[#efe6cd] shadow-xs'
                    : 'border-[#0D0D0D] bg-[#F7F1DE] hover:bg-[#f2ebd4]'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  {/* Skill identity and rank */}
                  <div className="flex items-center gap-3">
                    <span 
                      className={`w-8 h-8 rounded-[4px] font-bold text-sm flex items-center justify-center shrink-0 border border-[#0D0D0D] ${
                        isTopRanked
                          ? 'bg-[#A8842C] text-[#0D0D0D]'
                          : 'bg-[#0D0D0D] text-[#F7F1DE]'
                      }`}
                    >
                      #{index + 1}
                    </span>

                    <div className="flex flex-col">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-base font-bold text-[#0D0D0D]">
                          {skill.name}
                        </span>

                        {/* F2-3: Mark top-ranked missing skill as the first gap to close */}
                        {isTopRanked && (
                          <span className="border border-[#0D0D0D] bg-[#A8842C] text-[#0D0D0D] font-bold text-sm px-2.5 py-0.5 rounded-[4px] inline-flex items-center gap-1">
                            <span className="text-base leading-none">★</span>
                            <span>First gap to close</span>
                          </span>
                        )}

                        {/* F2-4: Alphabetical tie indicator */}
                        {isTied && (
                          <span 
                            title="Tied posting count with adjacent skill — sorted alphabetically"
                            className="border border-[#0D0D0D] bg-[#F7F1DE] text-[#0D0D0D] text-sm font-bold px-2 py-0.5 rounded-[4px] inline-flex items-center gap-1"
                          >
                            <Scale className="w-3.5 h-3.5 text-[#0D0D0D]" />
                            <span>Tied count &middot; Sorted A-Z</span>
                          </span>
                        )}
                      </div>

                      <span className="text-sm text-[#0D0D0D]">
                        Missing from Devon's current profile
                      </span>
                    </div>
                  </div>

                  {/* F2-2: Posting count beside each skill and total postings for the role */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                    <div className="text-left sm:text-right">
                      <div className="text-base font-bold text-[#0D0D0D]">
                        {skill.postingCount} of {totalPostings} postings
                      </div>
                      <div className="text-sm text-[#0D0D0D]">
                        {skill.percentage}% of market listings
                      </div>
                    </div>

                    {/* Interactive button (>= 44px thumb target) */}
                    <button
                      type="button"
                      onClick={() => onAddSkill(skill.name)}
                      className="min-h-[44px] min-w-[44px] px-3 py-2 bg-[#A8842C] text-[#0D0D0D] font-bold text-sm rounded-[4px] border border-[#0D0D0D] hover:opacity-90 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 shrink-0 focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#0D0D0D]"
                      title={`Add ${skill.name} to Devon's skills`}
                    >
                      <Plus className="w-4 h-4 text-[#0D0D0D]" />
                      <span className="hidden sm:inline">Add to Skills</span>
                    </button>
                  </div>
                </div>

                {/* Demand visualization bar */}
                <div className="w-full bg-[#e3dac1] h-3 rounded-[4px] overflow-hidden border border-[#0D0D0D]/40">
                  <div
                    className={`h-full transition-all duration-300 ${
                      isTopRanked ? 'bg-[#A8842C]' : 'bg-[#0D0D0D]'
                    }`}
                    style={{ width: `${Math.max(skill.percentage, 5)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
