import { TechRole } from '../types.ts';

export const INITIAL_DEVON_SKILLS = [
  'HTML',
  'CSS',
  'JavaScript',
  'React',
  'Git',
  'Python',
];

export const TECH_ROLES: TechRole[] = [
  {
    id: 'jr-frontend-dev',
    title: 'Junior Frontend Developer',
    category: 'Web Development',
    totalPostings: 32,
    description: 'Entry-level client-side web development creating reactive user interfaces and modern web applications.',
    postings: [
      {
        id: 'fe-1',
        title: 'Junior Frontend Engineer',
        company: 'Apex Cloud Solutions',
        location: 'Remote / Austin, TX',
        requiredSkills: ['JavaScript', 'React', 'TypeScript', 'CSS', 'Git'],
        snippet: 'Seeking a motivated junior engineer to craft responsive React components and assist with TypeScript migration.',
      },
      {
        id: 'fe-2',
        title: 'Associate Web Developer',
        company: 'Beacon Health Media',
        location: 'New York, NY',
        requiredSkills: ['HTML', 'CSS', 'JavaScript', 'TypeScript', 'Tailwind CSS'],
        snippet: 'Help maintain accessibility and modern CSS standards across patient and provider dashboards.',
      },
      {
        id: 'fe-3',
        title: 'Junior UI Engineer',
        company: 'Starlight E-Commerce',
        location: 'Chicago, IL',
        requiredSkills: ['React', 'JavaScript', 'TypeScript', 'Next.js', 'Jest'],
        snippet: 'Build and unit-test shopper storefront flows using Next.js and React.',
      },
      {
        id: 'fe-4',
        title: 'Entry Level Frontend Developer',
        company: 'FinPoint Technologies',
        location: 'Remote',
        requiredSkills: ['JavaScript', 'TypeScript', 'React', 'REST APIs', 'Git'],
        snippet: 'Work directly with API teams to integrate REST endpoints into clean, reusable React interfaces.',
      },
      {
        id: 'fe-5',
        title: 'Junior React Developer',
        company: 'CivicForge Systems',
        location: 'Washington, DC',
        requiredSkills: ['React', 'JavaScript', 'TypeScript', 'Next.js', 'Tailwind CSS'],
        snippet: 'Collaborate with designers to deliver public civic engagement tools built with Next.js.',
      },
      {
        id: 'fe-6',
        title: 'Junior Web Applications Developer',
        company: 'Kinetix Logistics',
        location: 'Atlanta, GA',
        requiredSkills: ['JavaScript', 'HTML', 'CSS', 'TypeScript', 'Jest'],
        snippet: 'Maintain core warehouse web portals and write automated unit tests with Jest.',
      },
      {
        id: 'fe-7',
        title: 'Associate Frontend Developer',
        company: 'Veloce Mobility',
        location: 'San Francisco, CA',
        requiredSkills: ['React', 'TypeScript', 'GraphQL', 'CSS', 'Git'],
        snippet: 'Integrate complex GraphQL schemas into real-time fleet monitoring web dashboards.',
      },
      {
        id: 'fe-8',
        title: 'Junior UI Software Engineer',
        company: 'Riverstone Data',
        location: 'Boston, MA',
        requiredSkills: ['React', 'TypeScript', 'Next.js', 'Figma', 'Git'],
        snippet: 'Translate Figma UI/UX designs into pixel-faithful accessible React components.',
      },
    ],
  },
  {
    id: 'jr-fullstack-dev',
    title: 'Junior Full-Stack Engineer',
    category: 'Software Engineering',
    totalPostings: 40,
    description: 'Entry-level full-stack engineer developing customer web services, APIs, and relational databases.',
    postings: [
      {
        id: 'fs-1',
        title: 'Junior Full-Stack Developer',
        company: 'MetroRail Digital',
        location: 'Remote',
        requiredSkills: ['JavaScript', 'React', 'Node.js', 'SQL', 'Git'],
        snippet: 'Develop customer ticketing portals and maintain backend Node.js microservices.',
      },
      {
        id: 'fs-2',
        title: 'Associate Software Engineer',
        company: 'Cedar Peak Analytics',
        location: 'Denver, CO',
        requiredSkills: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker'],
        snippet: 'Build analytics reporting dashboards backed by PostgreSQL and containerized services.',
      },
      {
        id: 'fs-3',
        title: 'Junior Web Engineer',
        company: 'Echo Payments',
        location: 'New York, NY',
        requiredSkills: ['JavaScript', 'Node.js', 'Express', 'SQL', 'Git'],
        snippet: 'Help maintain payment gateway APIs using Express and write secure database transactions.',
      },
      {
        id: 'fs-4',
        title: 'Entry Level Software Developer',
        company: 'Tideline Logistics',
        location: 'Seattle, WA',
        requiredSkills: ['TypeScript', 'Node.js', 'Docker', 'AWS', 'PostgreSQL'],
        snippet: 'Join our cloud infrastructure team deploying microservices on AWS.',
      },
    ],
  },
  {
    id: 'jr-data-analyst',
    title: 'Junior Data Analyst',
    category: 'Data & Analytics',
    totalPostings: 24,
    description: 'Entry-level analyst transforming business metrics into actionable dashboards and data pipelines.',
    postings: [
      {
        id: 'da-1',
        title: 'Junior Data Analyst',
        company: 'Urban Health Network',
        location: 'Philadelphia, PA',
        requiredSkills: ['SQL', 'Excel', 'Python', 'Power BI'],
        snippet: 'Write SQL queries and build weekly clinical performance reports.',
      },
      {
        id: 'da-2',
        title: 'Associate Analytics Consultant',
        company: 'Stratum Insights',
        location: 'Remote',
        requiredSkills: ['SQL', 'Python', 'Tableau', 'Excel', 'Statistics'],
        snippet: 'Clean client behavioral datasets using Pandas and visualize trends in Tableau.',
      },
      {
        id: 'da-3',
        title: 'Junior BI Analyst',
        company: 'Northstar Retail',
        location: 'Minneapolis, MN',
        requiredSkills: ['SQL', 'Power BI', 'Excel', 'Data Modeling'],
        snippet: 'Maintain inventory turnover dashboards in Power BI and audit discrepancy reports.',
      },
    ],
  },
  {
    id: 'embedded-firmware',
    title: 'Associate Embedded Firmware Engineer',
    category: 'Hardware & Systems',
    totalPostings: 6, // < 10 postings! To fulfill F2-5
    description: 'Entry-level embedded software developer writing firmware for microcontrollers and IoT sensors.',
    postings: [
      {
        id: 'emb-1',
        title: 'Associate Firmware Engineer',
        company: 'Pulse Sensor Labs',
        location: 'San Jose, CA',
        requiredSkills: ['C', 'C++', 'Microcontrollers', 'RTOS', 'Git'],
        snippet: 'Implement peripheral device drivers for ARM Cortex-M microcontrollers.',
      },
      {
        id: 'emb-2',
        title: 'Junior Embedded Systems Developer',
        company: 'AeroSat Technologies',
        location: 'Huntsville, AL',
        requiredSkills: ['C', 'Microcontrollers', 'Oscilloscopes', 'I2C/SPI'],
        snippet: 'Validate flight telemetry board communications over SPI and I2C protocols.',
      },
      {
        id: 'emb-3',
        title: 'Entry Firmware Programmer',
        company: 'TerraWatt Energy',
        location: 'Boulder, CO',
        requiredSkills: ['C', 'C++', 'Linux', 'Microcontrollers', 'Python'],
        snippet: 'Build battery management firmware and automate lab test benches using Python.',
      },
    ],
  },
  {
    id: 'jr-rust-systems',
    title: 'Junior Rust Systems Programmer',
    category: 'Systems & Infrastructure',
    totalPostings: 8, // < 10 postings! To fulfill F2-5
    description: 'Entry-level systems engineer building memory-safe infrastructure and distributed networking services.',
    postings: [
      {
        id: 'rst-1',
        title: 'Junior Systems Engineer',
        company: 'MeshGate Distributed',
        location: 'Remote',
        requiredSkills: ['Rust', 'Linux', 'Networking', 'Git', 'Docker'],
        snippet: 'Assist with high-throughput network packet parsing in safe Rust.',
      },
      {
        id: 'rst-2',
        title: 'Associate Infrastructure Developer',
        company: 'Solstice Storage',
        location: 'Portland, OR',
        requiredSkills: ['Rust', 'Linux', 'Multi-threading', 'Git'],
        snippet: 'Implement zero-copy block storage synchronization routines.',
      },
      {
        id: 'rst-3',
        title: 'Junior Protocol Engineer',
        company: 'Vanguard Ledger',
        location: 'Remote',
        requiredSkills: ['Rust', 'Docker', 'Cryptography', 'Linux'],
        snippet: 'Develop cryptographic verification pipelines and peer-to-peer relay daemons.',
      },
    ],
  },
  {
    id: 'tied-test-role',
    title: 'Junior Cloud Platform Specialist (Tied Skills Benchmark)',
    category: 'Cloud & Infrastructure',
    totalPostings: 20,
    description: 'Benchmark role with equal posting frequencies between skills to demonstrate deterministic alphabetical tie-breaking.',
    postings: [
      {
        id: 'cl-1',
        title: 'Junior Cloud Associate',
        company: 'Nimbus Core',
        location: 'Remote',
        requiredSkills: ['Docker', 'Kubernetes', 'AWS', 'Linux', 'Terraform', 'Git'],
        snippet: 'Build automated delivery pipelines for cloud-native applications.',
      },
    ],
  },
];

// Rich posting frequency matrix for accurate, realistic role skill demand
// F2-1: Order missing skills by posting count, highest first
// F2-2: Show posting count beside each skill and total postings
// F2-4: If two skills have the same count, order alphabetically
export const ROLE_SKILL_COUNTS: Record<string, Record<string, number>> = {
  'jr-frontend-dev': {
    'TypeScript': 27, // 27 of 32 postings (84%)
    'Next.js': 20,    // 20 of 32 postings (63%)
    'Tailwind CSS': 18,// 18 of 32 postings (56%)
    'Jest': 15,       // 15 of 32 (Tied with GraphQL)
    'GraphQL': 15,    // 15 of 32 (Tied with Jest -> Alphabetically: GraphQL comes before Jest!)
    'Figma': 12,      // 12 of 32 (Tied with REST APIs)
    'REST APIs': 12,  // 12 of 32 (Tied with Figma -> Alphabetically: Figma comes before REST APIs!)
    'Webpack': 8,     // 8 of 32 postings (25%)
    'React': 30,      // (Devon has this)
    'JavaScript': 32, // (Devon has this)
    'HTML': 32,       // (Devon has this)
    'CSS': 32,        // (Devon has this)
    'Git': 28,        // (Devon has this)
  },
  'jr-fullstack-dev': {
    'Node.js': 36,     // 36 of 40 postings (90%)
    'SQL': 32,         // 32 of 40 postings (80%)
    'PostgreSQL': 26,  // 26 of 40 postings (65%)
    'Docker': 24,      // 24 of 40 (Tied with TypeScript)
    'TypeScript': 24,  // 24 of 40 (Tied with Docker -> Alphabetically: Docker comes before TypeScript!)
    'Express': 20,     // 20 of 40 (Tied with AWS)
    'AWS': 20,         // 20 of 40 (Tied with Express -> Alphabetically: AWS comes before Express!)
    'CI/CD': 14,       // 14 of 40 postings
    'Redis': 11,       // 11 of 40 postings
    'JavaScript': 38,  // (Devon has this)
    'React': 34,       // (Devon has this)
    'Git': 35,         // (Devon has this)
    'Python': 18,      // (Devon has this)
  },
  'jr-data-analyst': {
    'SQL': 23,         // 23 of 24 postings (96%)
    'Excel': 21,       // 21 of 24 postings (88%)
    'Power BI': 16,    // 16 of 24 (Tied with Tableau)
    'Tableau': 16,     // 16 of 24 (Tied with Power BI -> Alphabetically: Power BI comes before Tableau!)
    'Pandas': 14,      // 14 of 24 postings
    'Statistics': 12,  // 12 of 24 (Tied with Data Modeling)
    'Data Modeling': 12,// 12 of 24 (Alphabetical: Data Modeling before Statistics!)
    'Python': 20,      // (Devon has this)
    'Git': 10,         // (Devon has this)
  },
  'embedded-firmware': {
    // Total: 6 postings (< 10)
    'C': 6,            // 6 of 6 (100%)
    'Microcontrollers': 5, // 5 of 6 (83%)
    'C++': 4,          // 4 of 6 (Tied with RTOS)
    'RTOS': 4,         // 4 of 6 (Tied with C++ -> Alphabetically: C++ comes before RTOS!)
    'I2C/SPI': 3,      // 3 of 6 (Tied with Oscilloscopes and Linux)
    'Linux': 3,        // 3 of 6
    'Oscilloscopes': 3,// 3 of 6 (Alphabetical: I2C/SPI -> Linux -> Oscilloscopes)
    'Python': 3,       // (Devon has this)
    'Git': 4,          // (Devon has this)
  },
  'jr-rust-systems': {
    // Total: 8 postings (< 10)
    'Rust': 8,         // 8 of 8 (100%)
    'Linux': 7,        // 7 of 8 (88%)
    'Docker': 5,       // 5 of 8 (Tied with Networking)
    'Networking': 5,   // 5 of 8 (Alphabetically: Docker comes before Networking!)
    'Multi-threading': 4, // 4 of 8 (Tied with Cryptography)
    'Cryptography': 4, // 4 of 8 (Alphabetically: Cryptography comes before Multi-threading!)
    'Git': 7,          // (Devon has this)
    'Python': 4,       // (Devon has this)
  },
  'tied-test-role': {
    // Total: 20 postings - explicitly designed to demonstrate tie breaking across multiple tiers
    'Docker': 16,      // 16 of 20 (Tied with Kubernetes)
    'Kubernetes': 16,  // 16 of 20 (Alphabetical: Docker comes before Kubernetes!)
    'AWS': 12,         // 12 of 20 (Tied with Terraform, Linux, Azure)
    'Azure': 12,       // 12 of 20
    'Linux': 12,       // 12 of 20
    'Terraform': 12,   // 12 of 20 (Alphabetical: AWS -> Azure -> Linux -> Terraform!)
    'Bash': 8,         // 8 of 20 (Tied with Helm)
    'Helm': 8,         // 8 of 20 (Alphabetical: Bash comes before Helm!)
    'Git': 18,         // (Devon has this)
    'Python': 14,      // (Devon has this)
  },
};
