/*
# Ranked Gaps: roles, postings, and required skills

1. New Tables
- `roles` — a job title Devon might search (e.g. "Frontend Developer").
  - id, name (unique), created_at
- `postings` — a job listing for a role. Count of postings per role drives
   ranking and the "small sample" warning (F2-5).
  - id, role_id (FK roles cascade), title, company, created_at
- `skills` — master list of skills referenced across postings.
  - id, name (unique), created_at
- `posting_skills` — many-to-many: which skills a given posting requires.
  - posting_id (FK cascade), skill_id (FK cascade), PK pair
  Count of postings for a role listing a skill = COUNT of rows here joined
  to postings for that role, used to rank missing skills (F2-1, F2-2).

2. Indexes
- posting_skills_skill_id_idx, postings_role_id_idx

3. Security
- Enable RLS on every table. Single-tenant, no-auth reference app: data is
  intentionally shared/read-only. TO anon, authenticated with USING (true).

4. Notes
- No user_id / auth.users linkage (no sign-in screen).
- Devon's "skills I have" live in browser localStorage, not the DB.
*/

CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS postings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  title text NOT NULL,
  company text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS posting_skills (
  posting_id uuid NOT NULL REFERENCES postings(id) ON DELETE CASCADE,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  PRIMARY KEY (posting_id, skill_id)
);

CREATE INDEX IF NOT EXISTS posting_skills_skill_id_idx ON posting_skills(skill_id);
CREATE INDEX IF NOT EXISTS postings_role_id_idx ON postings(role_id);

ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE postings ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE posting_skills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_roles" ON roles;
CREATE POLICY "anon_select_roles" ON roles FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_roles" ON roles;
CREATE POLICY "anon_insert_roles" ON roles FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_roles" ON roles;
CREATE POLICY "anon_update_roles" ON roles FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_roles" ON roles;
CREATE POLICY "anon_delete_roles" ON roles FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_postings" ON postings;
CREATE POLICY "anon_select_postings" ON postings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_postings" ON postings;
CREATE POLICY "anon_insert_postings" ON postings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_postings" ON postings;
CREATE POLICY "anon_update_postings" ON postings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_postings" ON postings;
CREATE POLICY "anon_delete_postings" ON postings FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_skills" ON skills;
CREATE POLICY "anon_select_skills" ON skills FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_skills" ON skills;
CREATE POLICY "anon_insert_skills" ON skills FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_skills" ON skills;
CREATE POLICY "anon_update_skills" ON skills FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_skills" ON skills;
CREATE POLICY "anon_delete_skills" ON skills FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_posting_skills" ON posting_skills;
CREATE POLICY "anon_select_posting_skills" ON posting_skills FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_posting_skills" ON posting_skills;
CREATE POLICY "anon_insert_posting_skills" ON posting_skills FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_posting_skills" ON posting_skills;
CREATE POLICY "anon_update_posting_skills" ON posting_skills FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_posting_skills" ON posting_skills;
CREATE POLICY "anon_delete_posting_skills" ON posting_skills FOR DELETE
  TO anon, authenticated USING (true);