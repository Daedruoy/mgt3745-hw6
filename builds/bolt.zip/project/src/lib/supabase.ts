import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Missing Supabase env vars. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: { persistSession: false },
});

export type Role = {
  id: string;
  name: string;
};

export type SkillCount = {
  skill_id: string;
  skill_name: string;
  postings_listing: number;
};

export type RoleSkillSummary = {
  role: Role;
  total_postings: number;
  skills: SkillCount[];
};

/**
 * Fetch all roles ordered alphabetically.
 */
export async function fetchRoles(): Promise<Role[]> {
  const { data, error } = await supabase
    .from('roles')
    .select('id, name')
    .order('name', { ascending: true });

  if (error) throw error;
  return data ?? [];
}

/**
 * Fetch the skill-posting summary for a single role:
 *  - total postings for the role
 *  - per skill, how many of those postings list it
 * Ordering (count DESC, name ASC) is enforced in the caller so the ranking
 * is deterministic across page loads (F2-4).
 */
export async function fetchRoleSkillSummary(
  roleId: string
): Promise<RoleSkillSummary> {
  // Total postings for the role
  const { count, error: countErr } = await supabase
    .from('postings')
    .select('id', { count: 'exact', head: true })
    .eq('role_id', roleId);

  if (countErr) throw countErr;

  // Join posting_skills -> skills -> postings(role) and aggregate counts.
  // We pull the raw rows and aggregate client-side so we control tie-break
  // ordering precisely (count DESC, name ASC).
  const { data, error } = await supabase
    .from('posting_skills')
    .select(
      'skill_id, skills!inner(id, name), postings!inner(role_id)'
    )
    .eq('postings.role_id', roleId);

  if (error) throw error;

  const bySkill = new Map<string, SkillCount>();
  for (const row of data ?? []) {
    const skill = row.skills as { id: string; name: string };
    const key = skill.id;
    const existing = bySkill.get(key);
    if (existing) {
      existing.postings_listing += 1;
    } else {
      bySkill.set(key, {
        skill_id: skill.id,
        skill_name: skill.name,
        postings_listing: 1,
      });
    }
  }

  const skills = Array.from(bySkill.values());
  skills.sort((a, b) =>
    b.postings_listing !== a.postings_listing
      ? b.postings_listing - a.postings_listing
      : a.skill_name.localeCompare(b.skill_name)
  );

  const roleRow = await supabase
    .from('roles')
    .select('id, name')
    .eq('id', roleId)
    .maybeSingle();
  if (roleRow.error) throw roleRow.error;

  return {
    role: roleRow.data as Role,
    total_postings: count ?? 0,
    skills,
  };
}
