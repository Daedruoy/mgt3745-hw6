import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Check,
  ChevronDown,
  CircleDot,
  Sparkles,
  Target,
} from 'lucide-react';
import {
  fetchRoles,
  fetchRoleSkillSummary,
  type Role,
  type RoleSkillSummary,
} from '@/lib/supabase';

const HAVE_SKILLS_KEY = 'ranked-gaps:have-skills';
const LAST_ROLE_KEY = 'ranked-gaps:last-role';

type LoadState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'ready'; summary: RoleSkillSummary }
  | { status: 'error'; message: string };

const SMALL_SAMPLE_THRESHOLD = 10;

function loadHaveSkills(): Record<string, boolean> {
  try {
    const raw = localStorage.getItem(HAVE_SKILLS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function saveHaveSkills(map: Record<string, boolean>) {
  try {
    localStorage.setItem(HAVE_SKILLS_KEY, JSON.stringify(map));
  } catch {
    /* ignore quota / privacy mode errors */
  }
}

function loadLastRoleId(): string | null {
  try {
    return localStorage.getItem(LAST_ROLE_KEY);
  } catch {
    return null;
  }
}

function saveLastRoleId(id: string | null) {
  try {
    if (id) localStorage.setItem(LAST_ROLE_KEY, id);
    else localStorage.removeItem(LAST_ROLE_KEY);
  } catch {
    /* ignore */
  }
}

export default function App() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [rolesError, setRolesError] = useState<string | null>(null);
  const [rolesLoading, setRolesLoading] = useState(true);

  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [haveSkills, setHaveSkills] = useState<Record<string, boolean>>(() =>
    loadHaveSkills()
  );
  const [summaryState, setSummaryState] = useState<LoadState>({
    status: 'idle',
  });

  // Load roles once
  useEffect(() => {
    let active = true;
    setRolesLoading(true);
    fetchRoles()
      .then((data) => {
        if (!active) return;
        setRoles(data);
        const last = loadLastRoleId();
        const initial =
          (last && data.some((r) => r.id === last) && last) ||
          (data.length > 0 ? data[0].id : null);
        setSelectedRoleId(initial);
      })
      .catch((err: unknown) => {
        if (!active) return;
        setRolesError(err instanceof Error ? err.message : String(err));
      })
      .finally(() => {
        if (active) setRolesLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  // Persist have-skills
  useEffect(() => {
    saveHaveSkills(haveSkills);
  }, [haveSkills]);

  // Persist last role
  useEffect(() => {
    saveLastRoleId(selectedRoleId);
  }, [selectedRoleId]);

  // Fetch skill summary whenever role changes
  useEffect(() => {
    if (!selectedRoleId) {
      setSummaryState({ status: 'idle' });
      return;
    }
    let active = true;
    setSummaryState({ status: 'loading' });
    fetchRoleSkillSummary(selectedRoleId)
      .then((summary) => {
        if (!active) return;
        setSummaryState({ status: 'ready', summary });
      })
      .catch((err: unknown) => {
        if (!active) return;
        setSummaryState({
          status: 'error',
          message: err instanceof Error ? err.message : String(err),
        });
      });
    return () => {
      active = false;
    };
  }, [selectedRoleId]);

  const toggleSkill = useCallback((skillId: string) => {
    setHaveSkills((prev) => ({ ...prev, [skillId]: !prev[skillId] }));
  }, []);

  const summary =
    summaryState.status === 'ready' ? summaryState.summary : null;

  // Compute ranked missing skills (F2-1, F2-4 ordering already from fetch;
  // re-apply defensively in case)
  const rankedMissing = useMemo(() => {
    if (!summary) return [];
    return summary.skills
      .filter((s) => !haveSkills[s.skill_id])
      .sort((a, b) =>
        b.postings_listing !== a.postings_listing
          ? b.postings_listing - a.postings_listing
          : a.skill_name.localeCompare(b.skill_name)
      );
  }, [summary, haveSkills]);

  const totalPostings = summary?.total_postings ?? 0;
  const isSmallSample =
    summary !== null && totalPostings < SMALL_SAMPLE_THRESHOLD;

  const haveCountInRole = summary
    ? summary.skills.filter((s) => haveSkills[s.skill_id]).length
    : 0;

  return (
    <div className="min-h-screen bg-cream text-ink font-body">
      <Header />

      <main className="mx-auto w-full max-w-[920px] px-4 pb-22 sm:px-6">
        <Intro />

        <section
          aria-label="Choose a role"
          className="mt-8 rounded-md border border-line bg-white/60 p-5 sm:p-6"
        >
          <RoleSelector
            roles={roles}
            loading={rolesLoading}
            error={rolesError}
            selectedRoleId={selectedRoleId}
            onSelect={setSelectedRoleId}
          />
        </section>

        {summary && (
          <section
            aria-label="Skills you already have"
            className="mt-8 rounded-md border border-line bg-white/60 p-5 sm:p-6 animate-fade-up"
          >
            <div className="flex items-baseline justify-between gap-4">
              <h2 className="font-heading text-xl font-bold text-ink">
                Skills you already have
              </h2>
              <span className="text-sm text-muted">
                {haveCountInRole} of {summary.skills.length} listed for this
                role
              </span>
            </div>
            <p className="mt-1 text-sm text-muted">
              Tap a chip to mark a skill you already have. The ranking below
              updates instantly.
            </p>
            <SkillPicker
              skills={summary.skills}
              haveSkills={haveSkills}
              onToggle={toggleSkill}
            />
          </section>
        )}

        <section
          aria-label="Ranked skill gaps"
          className="mt-8 rounded-md border border-line bg-white/60 p-5 sm:p-6"
        >
          <ResultsHeader
            roleName={summary?.role.name ?? null}
            totalPostings={totalPostings}
            isSmallSample={isSmallSample}
            hasSummary={summary !== null}
          />

          <ResultsBody
            state={summaryState}
            rankedMissing={rankedMissing}
            totalPostings={totalPostings}
            isSmallSample={isSmallSample}
            onToggleSkill={toggleSkill}
          />
        </section>

        <Footer />
      </main>
    </div>
  );
}

function Header() {
  return (
    <header className="border-b border-line bg-cream/95 backdrop-blur sticky top-0 z-10">
      <div className="mx-auto w-full max-w-[920px] px-4 sm:px-6 py-4 flex items-center gap-3">
        <Target className="text-accent" size={26} strokeWidth={2.25} />
        <div className="flex flex-col leading-tight">
          <span className="font-heading text-lg font-bold text-ink">
            Ranked Gaps
          </span>
          <span className="text-sm text-muted">
            See which missing skills matter most for a role
          </span>
        </div>
      </div>
      <div className="divider-gold" />
    </header>
  );
}

function Intro() {
  return (
    <div className="mt-8">
      <h1 className="font-heading text-3xl font-bold text-ink leading-tight">
        Should you apply, even if you don&apos;t meet every requirement?
      </h1>
      <p className="mt-3 text-base text-muted max-w-[640px]">
        Pick a tech role and the skills you already have. We rank the skills
        you&apos;re missing by how often real postings ask for them, so you
        know which gap to close first — and where you&apos;re closer to the
        bar than you think.
      </p>
    </div>
  );
}

type RoleSelectorProps = {
  roles: Role[];
  loading: boolean;
  error: string | null;
  selectedRoleId: string | null;
  onSelect: (id: string) => void;
};

function RoleSelector({
  roles,
  loading,
  error,
  selectedRoleId,
  onSelect,
}: RoleSelectorProps) {
  return (
    <div>
      <label
        htmlFor="role-select"
        className="block font-heading text-xl font-bold text-ink"
      >
        Choose a role
      </label>
      <p className="mt-1 text-sm text-muted">
        We count the job postings we have on file for this role and rank
        skills by how many of those postings list them.
      </p>

      <div className="mt-4 relative">
        <select
          id="role-select"
          className="focus-gold w-full appearance-none rounded-md border border-line bg-white px-4 py-3 pr-12 text-base text-ink min-h-[48px] disabled:opacity-60"
          value={selectedRoleId ?? ''}
          onChange={(e) => onSelect(e.target.value)}
          disabled={loading || !!error}
          aria-describedby="role-select-help"
        >
          {loading && <option value="">Loading roles…</option>}
          {error && <option value="">Could not load roles</option>}
          {!loading &&
            !error &&
            roles.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
        </select>
        <ChevronDown
          className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-muted"
          size={20}
        />
      </div>

      {error && (
        <p
          id="role-select-help"
          className="mt-2 text-sm text-error flex items-center gap-2"
        >
          <AlertTriangle size={16} /> {error}
        </p>
      )}
    </div>
  );
}

type SkillPickerProps = {
  skills: { skill_id: string; skill_name: string; postings_listing: number }[];
  haveSkills: Record<string, boolean>;
  onToggle: (id: string) => void;
};

function SkillPicker({ skills, haveSkills, onToggle }: SkillPickerProps) {
  if (skills.length === 0) {
    return (
      <p className="mt-4 text-sm text-muted">No skills listed for this role.</p>
    );
  }
  // Alphabetical for the picker so it's easy to find a skill
  const sorted = [...skills].sort((a, b) =>
    a.skill_name.localeCompare(b.skill_name)
  );
  return (
    <div
      role="group"
      aria-label="Toggle skills you have"
      className="mt-4 flex flex-wrap gap-2"
    >
      {sorted.map((s) => {
        const have = !!haveSkills[s.skill_id];
        return (
          <button
            key={s.skill_id}
            type="button"
            onClick={() => onToggle(s.skill_id)}
            aria-pressed={have}
            className={
              'focus-gold inline-flex items-center gap-1.5 rounded-full border px-3 py-2 min-h-[40px] text-sm transition-colors ' +
              (have
                ? 'bg-primary text-cream border-primary'
                : 'bg-white text-ink border-line hover:border-accent')
            }
          >
            {have ? (
              <Check size={15} strokeWidth={3} className="text-accent" />
            ) : (
              <CircleDot size={15} className="text-muted" />
            )}
            <span>{s.skill_name}</span>
          </button>
        );
      })}
    </div>
  );
}

type ResultsHeaderProps = {
  roleName: string | null;
  totalPostings: number;
  isSmallSample: boolean;
  hasSummary: boolean;
};

function ResultsHeader({
  roleName,
  totalPostings,
  isSmallSample,
  hasSummary,
}: ResultsHeaderProps) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-3">
      <div>
        <h2 className="font-heading text-xl font-bold text-ink">
          Ranked skill gaps
          {roleName ? <span className="text-muted"> · {roleName}</span> : null}
        </h2>
        {hasSummary && (
          <p className="mt-1 text-sm text-muted">
            Missing skills ordered by how many postings list them, highest
            first.
          </p>
        )}
      </div>

      {hasSummary && (
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted">
            Postings for this role:{' '}
            <span className="font-bold text-ink">{totalPostings}</span>
          </span>
          {isSmallSample && (
            <span
              className="inline-flex items-center gap-1.5 rounded-full border border-warning/40 bg-warning/10 px-3 py-1.5 text-sm text-warning"
              title="Fewer than 10 postings means the ranking may not be stable."
            >
              <AlertTriangle size={15} />
              Small sample
            </span>
          )}
        </div>
      )}
    </div>
  );
}

type ResultsBodyProps = {
  state: LoadState;
  rankedMissing: {
    skill_id: string;
    skill_name: string;
    postings_listing: number;
  }[];
  totalPostings: number;
  isSmallSample: boolean;
  onToggleSkill: (id: string) => void;
};

function ResultsBody({
  state,
  rankedMissing,
  totalPostings,
  isSmallSample,
  onToggleSkill,
}: ResultsBodyProps) {
  if (state.status === 'loading' || state.status === 'idle') {
    return (
      <div className="mt-6">
        <SkeletonRow />
        <SkeletonRow />
        <SkeletonRow />
        <SkeletonRow />
      </div>
    );
  }

  if (state.status === 'error') {
    return (
      <div
        role="alert"
        className="mt-6 rounded-md border border-error/30 bg-error/5 px-4 py-3 text-sm text-error flex items-start gap-2"
      >
        <AlertTriangle size={18} className="mt-0.5 shrink-0" />
        <span>
          We couldn&apos;t load the skill ranking. {state.message}
        </span>
      </div>
    );
  }

  if (rankedMissing.length === 0) {
    return (
      <div className="mt-6 rounded-md border border-line bg-white px-4 py-6 text-center">
        <Sparkles className="mx-auto text-accent" size={28} />
        <p className="mt-2 font-heading text-lg font-bold text-ink">
          You have every listed skill
        </p>
        <p className="mt-1 text-sm text-muted">
          Nothing in our postings is missing from your skill set. Apply with
          confidence.
        </p>
      </div>
    );
  }

  const firstGap = rankedMissing[0];
  const maxCount = firstGap.postings_listing;

  return (
    <div className="mt-6">
      <FirstGapCallout
        skillName={firstGap.skill_name}
        postingsListing={firstGap.postings_listing}
        totalPostings={totalPostings}
        isSmallSample={isSmallSample}
      />

      <ol className="mt-6 flex flex-col gap-2">
        {rankedMissing.map((skill, idx) => (
          <RankRow
            key={skill.skill_id}
            rank={idx + 1}
            skillName={skill.skill_name}
            postingsListing={skill.postings_listing}
            totalPostings={totalPostings}
            maxCount={maxCount}
            isFirst={idx === 0}
            onMarkHave={() => onToggleSkill(skill.skill_id)}
          />
        ))}
      </ol>
    </div>
  );
}

function FirstGapCallout({
  skillName,
  postingsListing,
  totalPostings,
  isSmallSample,
}: {
  skillName: string;
  postingsListing: number;
  totalPostings: number;
  isSmallSample: boolean;
}) {
  const pct =
    totalPostings > 0 ? Math.round((postingsListing / totalPostings) * 100) : 0;
  return (
    <div className="rounded-md border border-accent/50 bg-accent/10 px-4 py-4 sm:px-5 sm:py-5">
      <div className="flex items-center gap-2 text-accent">
        <Target size={18} strokeWidth={2.5} />
        <span className="font-heading text-sm font-bold uppercase tracking-wide">
          First gap to close
        </span>
      </div>
      <p className="mt-2 font-heading text-2xl font-bold text-ink">
        {skillName}
      </p>
      <p className="mt-1 text-sm text-ink/80">
        Listed in{' '}
        <strong className="text-ink">
          {postingsListing} of {totalPostings}
        </strong>{' '}
        postings ({pct}%)
        {isSmallSample && (
          <span className="text-warning"> · small sample, treat as a hint</span>
        )}
      </p>
    </div>
  );
}

function RankRow({
  rank,
  skillName,
  postingsListing,
  totalPostings,
  maxCount,
  isFirst,
  onMarkHave,
}: {
  rank: number;
  skillName: string;
  postingsListing: number;
  totalPostings: number;
  maxCount: number;
  isFirst: boolean;
  onMarkHave: () => void;
}) {
  const pct =
    totalPostings > 0 ? (postingsListing / totalPostings) * 100 : 0;
  const barPct = maxCount > 0 ? (postingsListing / maxCount) * 100 : 0;

  return (
    <li
      className={
        'rounded-md border bg-white px-4 py-3 transition-shadow ' +
        (isFirst
          ? 'border-accent/60 shadow-sm'
          : 'border-line hover:border-accent/40')
      }
    >
      <div className="flex items-center gap-3">
        <span
          className={
            'shrink-0 grid place-items-center w-7 h-7 rounded-full text-sm font-bold ' +
            (isFirst
              ? 'bg-accent text-cream'
              : 'bg-creamDark text-ink')
          }
          aria-label={`Rank ${rank}`}
        >
          {rank}
        </span>

        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-3">
            <span className="truncate font-bold text-ink text-base">
              {skillName}
            </span>
            <span className="shrink-0 text-sm text-muted whitespace-nowrap">
              <span className="font-bold text-ink">{postingsListing}</span> of{' '}
              {totalPostings} postings
            </span>
          </div>

          {/* Bar */}
          <div
            className="mt-2 h-2 w-full rounded-full bg-creamDark overflow-hidden"
            role="presentation"
          >
            <div
              className={
                'h-full rounded-full transition-all duration-300 ' +
                (isFirst ? 'bg-accent' : 'bg-ink/70')
              }
              style={{ width: `${barPct}%` }}
            />
          </div>
          <span className="mt-1 block text-sm text-muted">
            {Math.round(pct)}% of postings list this skill
          </span>
        </div>

        <button
          type="button"
          onClick={onMarkHave}
          className="focus-gold shrink-0 inline-flex items-center gap-1 rounded-md border border-line bg-white px-2.5 py-2 min-h-[40px] text-sm text-ink hover:border-accent transition-colors"
          aria-label={`Mark ${skillName} as a skill I have`}
          title={`Mark ${skillName} as a skill I have`}
        >
          <Check size={16} className="text-success" />
          <span className="hidden sm:inline">I have this</span>
        </button>
      </div>

      {isFirst && (
        <div className="mt-2 pl-10 text-sm text-accent flex items-center gap-1.5">
          <ArrowRight size={14} />
          <span>Highest-impact gap — focus here first.</span>
        </div>
      )}
    </li>
  );
}

function SkeletonRow() {
  return (
    <div className="rounded-md border border-line bg-white px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="w-7 h-7 rounded-full bg-creamDark animate-pulse" />
        <div className="flex-1">
          <div className="h-4 w-40 rounded bg-creamDark animate-pulse" />
          <div className="mt-2 h-2 w-full rounded bg-creamDark animate-pulse" />
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-12 mb-4">
      <div className="divider-gold" />
      <p className="mt-4 text-sm text-muted">
        Counts come from job postings stored for each role. When a role has
        fewer than 10 postings, the ranking is a hint, not a verdict — apply
        anyway if the role fits.
      </p>
    </footer>
  );
}
