/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#0D0D0D',
        accent: '#A8842C',
        accentDark: '#8A6A22',
        background: '#F7F1DE',
        cream: '#F7F1DE',
        creamDark: '#EFE7C9',
        ink: '#0D0D0D',
        muted: '#5C5446',
        line: '#E2D9BC',
        success: '#2E6B4F',
        warning: '#9A6A1F',
        error: '#8C2D2D',
      },
      fontFamily: {
        body: ['Arial', 'Helvetica', 'sans-serif'],
        heading: ['Arial', 'Helvetica', 'sans-serif'],
      },
      borderRadius: {
        DEFAULT: '4px',
        sm: '4px',
        md: '4px',
        lg: '6px',
      },
      spacing: {
        // 8px unit system helpers (Tailwind already multiples of 4)
        18: '72px',
        22: '88px',
        30: '120px',
      },
      fontSize: {
        // Never below 14px (font-size-min). Tailwind's xs/sm are 12/14.
        xs: ['14px', { lineHeight: '20px' }],
        sm: ['14px', { lineHeight: '20px' }],
        base: ['16px', { lineHeight: '24px' }],
        lg: ['18px', { lineHeight: '26px' }],
        xl: ['20px', { lineHeight: '28px' }],
        '2xl': ['24px', { lineHeight: '30px' }],
        '3xl': ['30px', { lineHeight: '36px' }],
      },
    },
  },
  plugins: [],
};
